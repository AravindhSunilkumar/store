
<?php
require_once 'init.php';
$student = new Student();
$class = new class_details();
$hobbies = new student_hobbies();
if (($_SERVER['REQUEST_METHOD'] == 'GET') && (isset($_GET['filter']))) {
    $c_id = isset($_GET['id']) && $_GET['id'] !== 'default' ?$student->getDb()->real_escape_string($_GET['id']) : '';
    $studentname = isset($_GET['studentname']) ?$student->getDb()->real_escape_string($_GET['studentname']) : '';
    $result = $student->getfilterStudent($studentname,$c_id);
    $smarty->assign('students', $result);
    $smarty->assign('filter', 1);
    $smarty->assign('c_id', $c_id);
    $smarty->assign('studentname', $studentname);
    $smarty->assign('classes', $class->getClasses());
    $smarty->display('view.tpl.html');
}else{
    $result = $student->getStudents();
    $smarty->assign('filter', 0);
    $smarty->assign('classes', $class->getClasses());
    $smarty->assign('students', $result);
    $smarty->display('view.tpl.html');
}
if (isset($_GET['action']) && $_GET['action'] == 'updatestatus') {
    $id = (int)$_GET['id'];
    $status = $_GET['status'];

    $status = ($status == 'active') ? 'active' : 'inactive';
    $result = $student->updateStatus($id, $status);
    echo $result;
    
  }
?>