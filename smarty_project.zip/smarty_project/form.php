<?php
require_once 'init.php';
$hobbies = new student_hobbies();
$student = new Student();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
    // Validate required fields
    if (!empty($_POST['age']) && !empty($_POST['gender']) && !empty($_POST['class'])) {
        
        $student_id = $student->getDb()->real_escape_string($student->registerId());
        
        
        $target_file = $student->uploadImage($_FILES["file"], $student_id);
        if ($target_file === false) {
            echo "<script>alert('File upload failed.');</script>";
            echo "<script>window.location.href = 'form.php';</script>";
            return;
        }
        
        
        $fname = $student->getDb()->real_escape_string($_POST['fname']);
        $lname = $student->getDb()->real_escape_string($_POST['lname']);
        $name = $fname . " " . $lname;
        $age = $student->getDb()->real_escape_string($_POST['age']);
        $gender = $student->getDb()->real_escape_string($_POST['gender']);
        $class = $student->getDb()->real_escape_string($_POST['class']);
        $dob = $student->getDb()->real_escape_string($_POST['dob']);
        $hobbies = implode(',', array_map(array($student->getDb(), 'real_escape_string'), $_POST['hobbies']));

        // Get the priority value from the database
        $priority = $student->getPriority();

        // Insert the student record
        $last_id = $student->insertStudent($name, $class, $age, $gender, $priority, $target_file, $student_id, $dob, $hobbies);

        if ($last_id) {
            // Handle gallery file uploads
            if (!empty($_FILES['files']['name'][0])) {
                foreach ($_FILES['files']['name'] as $key => $value) {
                    $file = array(
                        'name' => $_FILES['files']['name'][$key],
                        'type' => $_FILES['files']['type'][$key],
                        'tmp_name' => $_FILES['files']['tmp_name'][$key],
                        'error' => $_FILES['files']['error'][$key],
                        'size' => $_FILES['files']['size'][$key]
                    );
                    $gallery_file = $student->uploadImage($file, rand(0000, 9999));  // Random number for the gallery image
                    if ($gallery_file !== false) {
                        $student->insertGallery($last_id, $gallery_file);
                    }
                }
            }

            // Handle parent details insertion
            $father_name = $student->getDb()->real_escape_string($_POST['fathername']);
            $fphonenumber = $student->getDb()->real_escape_string($_POST['fphonenumber']);
            $femailid = $student->getDb()->real_escape_string($_POST['femailid']);
            $mothername = $student->getDb()->real_escape_string($_POST['mothername']);
            $mphonenumber = $student->getDb()->real_escape_string($_POST['mphonenumber']);
            $memailid = $student->getDb()->real_escape_string($_POST['memailid']);
            $primary = $student->getDb()->real_escape_string($_POST['primary']);

            $student->insertParentDetails($last_id, $father_name, $fphonenumber, $femailid, $mothername, $mphonenumber, $memailid, $primary);

            // Redirect with success message
            echo "<script>
                alert('Student added successfully!'); window.location.href = 'form.php';
            </script>";

        } else {
            echo "<script>alert('Error: Unable to insert student.');</script>";
        }
    } else {
        echo "<script>alert('Data is missing'); window.location.href = 'form.php';</script>";
    }
}
//age calculation
$class = new class_details();
if($_SERVER['REQUEST_METHOD'] == 'GET' and (isset($_GET['dob']))){
    $dob = $_GET['dob'];
    $result = $class->getAgeAndClasses($dob);

    header('Content-Type: application/json');
    echo json_encode(array("status" => $result['age'], "classes" => $result['classes']));
    exit;
}

$smarty->assign('hobbies', $hobbies->getHobbies());
$smarty->assign('registerid', $student->registerId());
$smarty->display('form.tpl.html');
?>
