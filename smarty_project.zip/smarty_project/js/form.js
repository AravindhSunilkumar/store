document.getElementById("fname").focus();
 
 



 
  function dobCall(val) {
      // document.getElementById('blockScreen').style.display = 'block';
      // document.querySelector('.dblur').style.filter = 'blur(8px)';
      const apiUrl = 'form.php?dob=' + val;

      fetch(apiUrl)
          .then(response => {
              if (!response.ok) {
                  throw new Error('Network response was not ok');
              }
              return response.json();
          })
          .then(data => {
              // Update the age field
              document.getElementById("age").value = data.status;

              // Get class select element
              let classSelect = document.getElementById("class_id");
              classSelect.innerHTML = '<option value="">Select Class</option>'; // Reset options

              if (data.classes.length > 0) {
                  // Append new options from API response
                  data.classes.forEach(cls => {
                      let option = document.createElement("option");
                      option.value = cls.id;
                      option.textContent = cls.class;
                      classSelect.appendChild(option);
                  });
                  document.getElementById('alertage').innerHTML = '';
                  document.getElementById('alertdob').innerHTML = '';
                  document.getElementById('alertclass').innerHTML = '';
              } else {
                  // alert('No class available for the selected age.');
                  document.getElementById('alertage').innerHTML = 'No class available for the selected dob.';
                  document.getElementById('alertdob').innerHTML = 'Enter a valid dob.';
                  document.getElementById('alertclass').innerHTML = 'No class available for the selected dob.';
                  document.getElementById("age").value = '';
                  // document.getElementById("dob").value = '';
              }

              // document.getElementById('blockScreen').style.display = 'none';
              // document.querySelector('.dblur').style.filter = 'none';
          })
          .catch(error => {
              console.error('Error:', error);
              document.getElementById('blockScreen').style.display = 'none';
              document.querySelector('.dblur').style.filter = 'none';
          });
  }


  function validate() {
    document.getElementById('blockScreen').style.display = 'block';
    document.querySelector('.dblur').style.filter = 'blur(8px)';  
    
    const fname = document.getElementById('fname').value.trim();
    const lname = document.getElementById('lname').value.trim();
    const age = document.getElementById('age').value;
    const dob = document.getElementById('dob').value;
    const class_id = document.getElementById('class_id').value.trim();
    const file = document.getElementById('file').value;
    const gender = document.querySelector('input[name="gender"]:checked');
    const fatherName = document.getElementById('fathername').value.trim();
    const fatherPhone = document.getElementById('fphonenumber').value.trim();
    const fatherEmail = document.getElementById('femailid').value.trim();
    const motherName = document.getElementById('mothername').value.trim();
    const motherPhone = document.getElementById('mphonenumber').value.trim();
    const motherEmail = document.getElementById('memailid').value.trim();
    const primaryContact = document.querySelector('input[name="primary"]:checked');
    
    let firstErrorField = null; // Track the first field that has an error

    // Name validation
    if (fname === '') {
        document.getElementById('alertfname').innerHTML = 'First Name is required.';
        if (!firstErrorField) firstErrorField = document.getElementById('fname');
    } else {
        document.getElementById('alertfname').innerHTML = '';
    }
    
    if (lname === '') {
        document.getElementById('alertlname').innerHTML = 'Last Name is required.';
        if (!firstErrorField) firstErrorField = document.getElementById('lname');
    } else {
        document.getElementById('alertlname').innerHTML = '';
    }
    
    // Date of birth validation
    if (dob === '') {
        document.getElementById('alertdob').innerHTML = 'Date of birth is required.';
        if (!firstErrorField) firstErrorField = document.getElementById('dob');
    } else {
        document.getElementById('alertdob').innerHTML = '';
    }

    // Age validation
    if (age === '' || age <= 0) {
        document.getElementById('alertage').innerHTML = 'Please enter a valid age.';
        if (!firstErrorField) firstErrorField = document.getElementById('age');
    } else {
        document.getElementById('alertage').innerHTML = '';
    }

    // Class validation
    if (class_id === '') {
        document.getElementById('alertclass').innerHTML = 'Class is required.';
        if (!firstErrorField) firstErrorField = document.getElementById('class_id');
    } else {
        document.getElementById('alertclass').innerHTML = '';
    }

    // Image upload validation
    if (file === '') {
        document.getElementById('alertimage').innerHTML = 'Image is required.';
        if (!firstErrorField) firstErrorField = document.getElementById('file');
    } else {
        document.getElementById('alertimage').innerHTML = '';
    }

    // Gender validation
    if (!gender) {
        document.getElementById('alertgender').innerHTML = 'Gender is required.';
        if (!firstErrorField) firstErrorField = document.querySelector('input[name="gender"]');
    } else {
        document.getElementById('alertgender').innerHTML = '';
    }

    // Father name validation
    if (fatherName === '') {
        document.getElementById('fathername').nextElementSibling.textContent = 'Father Name is required.';
        if (!firstErrorField) firstErrorField = document.getElementById('fathername');
    } else {
        document.getElementById('fathername').nextElementSibling.textContent = '';
    }

    // Father phone validation
    if (fatherPhone === '' || !/^\d{10}$/.test(fatherPhone)) {
        document.getElementById('fphonenumber').nextElementSibling.textContent = 'Please enter a valid 10-digit Father Mobile Number.';
        if (!firstErrorField) firstErrorField = document.getElementById('fphonenumber');
    } else {
        document.getElementById('fphonenumber').nextElementSibling.textContent = '';
    }

    // Father email validation
    if (fatherEmail === '' || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fatherEmail)) {
        document.getElementById('femailid').nextElementSibling.textContent = 'Please enter a valid Father Email Id.';
        if (!firstErrorField) firstErrorField = document.getElementById('femailid');
    } else {
        document.getElementById('femailid').nextElementSibling.textContent = '';
    }

    // Mother name validation
    if (motherName === '') {
        document.getElementById('mothername').nextElementSibling.textContent = 'Mother Name is required.';
        if (!firstErrorField) firstErrorField = document.getElementById('mothername');
    } else {
        document.getElementById('mothername').nextElementSibling.textContent = '';
    }

    // Mother phone validation
    if (motherPhone === '' || !/^\d{10}$/.test(motherPhone)) {
        document.getElementById('mphonenumber').nextElementSibling.textContent = 'Please enter a valid 10-digit Mother Mobile Number.';
        if (!firstErrorField) firstErrorField = document.getElementById('mphonenumber');
    } else {
        document.getElementById('mphonenumber').nextElementSibling.textContent = '';
    }

    // Mother email validation
    if (motherEmail === '' || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(motherEmail)) {
        document.getElementById('memailid').nextElementSibling.textContent = 'Please enter a valid Mother Email Id.';
        if (!firstErrorField) firstErrorField = document.getElementById('memailid');
    } else {
        document.getElementById('memailid').nextElementSibling.textContent = '';
    }

    // Primary contact validation
    if (!primaryContact) {
        document.getElementById('alertprimary').innerHTML = 'Primary contact is required.';
        if (!firstErrorField) firstErrorField = document.querySelector('input[name="primary"]');
    } else {
        document.getElementById('alertprimary').innerHTML = '';
    }
    
    if (firstErrorField) {
        firstErrorField.focus();  // Focus the first field with an error
    }
    
    return !firstErrorField;  // Return false if there's an error
}


function showViewButton() {
    const fileInput = document.getElementById('file');
    const file = fileInput.files[0];
    const validImageTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/gif'];

    if (!validImageTypes.includes(file.type)) {
        alert('Invalid file type. Please upload an image file (jpg, jpeg, png, gif).');
        fileInput.value = ''; // Clear the input
        document.getElementById('viewButton').style.display = 'none';
        return;
    }

    if (file.size > 5000000) { // 5MB
        alert('File size exceeds 5MB. Please upload a smaller file.');
        fileInput.value = ''; // Clear the input
        document.getElementById('viewButton').style.display = 'none';
        return;
    }

    document.getElementById('viewButton').style.display = 'inline-block';
}

function viewImage() {
    const fileInput = document.getElementById('file');
    const file = fileInput.files[0];
    const reader = new FileReader();
    reader.onload = function() {
        const output = document.getElementById('imagePreview');
        output.src = reader.result;
        const imageModal = new bootstrap.Modal(document.getElementById('imageModal'));
        imageModal.show();
    };
    reader.readAsDataURL(file);
}




function showGalleryButton() {
    const filesInput = document.getElementById('files');
    const files = filesInput.files;
    const validImageTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/gif'];
    let valid = true;

    Array.from(files).forEach(file => {
        if (!validImageTypes.includes(file.type) || file.size > 5000000) { // 5MB
            valid = false;
        }
    });

    if (!valid) {
        alert('Invalid file type or file size exceeds 5MB in gallery. Please upload image files (jpg, jpeg, png, gif) below 5MB.');
        filesInput.value = ''; // Clear the input
        document.getElementById('galleryButton').style.display = 'none';
        return;
    }

    document.getElementById('galleryButton').style.display = 'inline-block';
}

function viewGallery() {
    const filesInput = document.getElementById('files');
    const files = filesInput.files;
    const galleryPreview = document.getElementById('galleryPreview');
    galleryPreview.innerHTML = ''; // Clear previous previews

    Array.from(files).forEach(file => {
        const reader = new FileReader();
        reader.onload = function() {
            const img = document.createElement('img');
            img.src = reader.result;
            img.style.maxWidth = '100px';
            img.style.margin = '5px';
            galleryPreview.appendChild(img);
        };
        reader.readAsDataURL(file);
    });

    const galleryModal = new bootstrap.Modal(document.getElementById('galleryModal'));
    galleryModal.show();
}

