<?php
if(($_SERVER['REQUEST_METHOD'] == 'GET') && (isset($_GET['id']))){
    $details = $student->getStudentById($_GET['id']);
    $smarty->assign('details', $details);
    $smarty->assign('classes', $class->getClasses());
    $smarty->assign('hobbies', $hobbies->getHobbies());
    $smarty->display('update_details.tpl.html');

}else{
    echo "<script>alert('Data is missing'); window.location.href = 'view.php';</script>";
}
?>