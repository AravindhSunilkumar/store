<?php
require_once 'init.php';
$student = new Student();
header('Content-Type: application/json');

// Decode the incoming JSON request
$data = json_decode(file_get_contents("php://input"), true);

if ($data) {
    // Process each row
    foreach ($data as $row) {
        $id = (int) $row['id'];  
        $priority = (int) $row['priority']; 
        
        
        if (isset($row['id']) && isset($row['priority'])) {
           echo $student->updatePriority($id, $priority);
        } else {
            echo $student->updatePriority($id, $priority);
        }
    }
} else {
    echo json_encode(array("error" => "Invalid JSON format"));
}



?>