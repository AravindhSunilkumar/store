<?php /* Smarty version 2.6.19, created on 2025-02-19 18:03:27
         compiled from view.tpl.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'capitalize', 'view.tpl.html', 97, false),)), $this); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css_files/view.css">
</head>
<body>
  <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'nav.tpl.html', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
    <div class="container col-12  justify-content-center mt-4 ">
        <div class="col-12 d-flex justify-content-center">
     <!-- loader -->
  <div id="blockScreen" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background-color:rgba(0, 0, 0, 0.22); z-index:9999;">
    <div id="loader"   style=" position: absolute; left: 50%; top: 35%;" class="spinner-grow text-info" role="status">
        <span class="visually-hidden">Loading...</span>
    </div>           
  </div>
  <!-- loader end -->

  <!-- Modal -->
<div id="myModal" role="dialog" style="display: none;">
    <div class="modal-dialog">
      
      <div class="modal-content" style="width: 88%;">
        <div class="modal-header" style="background-color:rgb(255, 255, 255);">
          <a href="#" class="close" data-dismiss="modal" style="position: absolute;right: 2px;top: -15px;color:black;">&times;</a>
          <h4 class="modal-title">Photo</h4>
        </div>
        <div class="modal-body" id="modalBody" style="background-color: #ffffff;">
        </div>
        
      </div>
    </div>
  </div>
    <div class="border shadow rounded">
        <div class="row col-12 d-flex text-align-center ">
          <div class="row col-12">
            <div class="row col-12 mt-2">
              <!-- <div class="col-2">
              </div> -->
              <div class="col-12">
      
                <h2 class="text-center">Students View</h2>
              </div>
            </div>
            <h2 style = "margin-left:1%;">Search Students</h2>
            <div class="col-10">
              <form action="student_view.php" method="get">
                <div class="col-8 d-flex" style = "margin-left:1%;">
                  <select class="form-select me-2" name="id" aria-label="Default select example">
                    <option value="">Select a Class</option>
                    <?php $_from = $this->_tpl_vars['classes']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['class']):
?>
                      <option value="<?php echo $this->_tpl_vars['class']['id']; ?>
" <?php if ($this->_tpl_vars['class']['id'] == $this->_tpl_vars['c_id']): ?> selected <?php endif; ?>><?php echo $this->_tpl_vars['class']['class']; ?>
</option>
                    <?php endforeach; endif; unset($_from); ?>
                  </select>
                  <input type="text" name="studentname" id="student_name" value="<?php echo $this->_tpl_vars['studentname']; ?>
" class="form-control me-2" placeholder="Enter a Name or Register ID">
                  <!-- <input type="text" name="registerid" id="registerid" value="<?php echo '<?php'; ?>
 echo (isset($_GET['registerid'])) ? $_GET['registerid'] : ''; <?php echo '?>'; ?>
" class="form-control me-2" placeholder="Enter a register ID"> -->
                  <input type="submit" value="Filter" name="filter" class="btn btn-primary me-2">
                  <a href="student_view.php" class="btn btn-warning">Clear</a>
                </div>
              </form>
            </div>
            <div class="col-2 d-flex justify-content-end">
              <strong class="mt-2">Add Student</strong>
              <a href="form.php" class=""><img src="https://img.icons8.com/?size=100&id=wj3Kwq4QqnVW&format=png&color=000000" alt="add student" width="40px" height = "40px"></a>
            </div>
          </div>
        </div>
        <div class="container dblur">
    <table class="table table-primary dblur table-overflow rounded" id="studentTable">
        <?php if ($this->_tpl_vars['filter'] == 1): ?>
        <thead>
            <tr>
                <th scope="col" style="text-align: center;">Registration Id</th>
                <th scope="col">Name</th>
                <th scope="col" style="text-align: center;">Class</th>
                <th scope="col" style="text-align: center;">Age</th>
                <th scope="col" style="text-align: center;">Dob</th>
                <th scope="col" style="text-align: center;">Gender</th>
                <th scope="col" style="text-align: center;">Action</th>
                <th scope="col" style="text-align: center;">Image</th>
                <th scope="col" style="text-align: center;">Gallery</th>
                <th scope="col" style="text-align: center;">Details</th>
                <th scope="col" style="">Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $_from = $this->_tpl_vars['students']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['student']):
?>
            <tr>
                <td class='text-center'><?php echo $this->_tpl_vars['student']['register_id']; ?>
</td>
                <td><?php echo $this->_tpl_vars['student']['name']; ?>
</td>
                <td class='text-center'><?php echo ((is_array($_tmp=$this->_tpl_vars['student']['class'])) ? $this->_run_mod_handler('capitalize', true, $_tmp) : smarty_modifier_capitalize($_tmp)); ?>
</td>
                <td class='text-center'><?php echo $this->_tpl_vars['student']['age']; ?>
</td>
                <td class='text-center'><?php echo $this->_tpl_vars['student']['dob']; ?>
</td>
                <td class='text-center'><?php echo $this->_tpl_vars['student']['gender']; ?>
</td>
                <td class='text-center'>
                    <a href='<?php echo $this->_tpl_vars['self']; ?>
?action=update&id=<?php echo $this->_tpl_vars['student']['id']; ?>
'>
                        <img src='./images/edit.png' style='width:20px;height:auto;'>
                    </a>
                    <div style='display:inline-block; width:10px;'></div>
                    <a href='#' onclick='confirmDelete("<?php echo $this->_tpl_vars['student']['id']; ?>
")'>
                        <img src='./images/delete.png' style='width:20px;height:auto;'>
                    </a>
                </td>
                <td class='text-center'>
                    <a href='#' onclick='passMessage("<?php echo $this->_tpl_vars['student']['photo']; ?>
")'>
                        <img src='./images/witness.png' style='width:20px;height:auto;'>
                    </a>
                </td>
                <td class='text-center'>
                    <a href='<?php echo $this->_tpl_vars['self']; ?>
?action=gallery&id=<?php echo $this->_tpl_vars['student']['id']; ?>
'>
                        <img src='./images/gallery.png' style='width:20px;height:auto;'>
                    </a>
                </td>
                <td>
                    <a style='text-decoration:none;' href='#modal-10' id='details' class='btn-sm btn-success' 
                        data-father-name='<?php echo $this->_tpl_vars['student']['father_name']; ?>
' data-father-number='<?php echo $this->_tpl_vars['student']['father_number']; ?>
' 
                        data-father-mail='<?php echo $this->_tpl_vars['student']['father_mail']; ?>
' data-mother-name='<?php echo $this->_tpl_vars['student']['mother_name']; ?>
' 
                        data-mother-number='<?php echo $this->_tpl_vars['student']['mother_number']; ?>
' data-mother-mail='<?php echo $this->_tpl_vars['student']['mother_mail']; ?>
' 
                        data-student-name='<?php echo $this->_tpl_vars['student']['name']; ?>
'>
                        <i class='text-success'>Parents Details</i>
                    </a>
                </td>
                <td class='text-center'>
                  <div class='form-check form-switch'>
                      <input class='form-check-input input-switch' type='checkbox' id='<?php echo $this->_tpl_vars['student']['id']; ?>
' <?php if ($this->_tpl_vars['student']['status'] == 'active'): ?>checked<?php endif; ?>>
                  </div>
              </td>

            </tr>
            <?php endforeach; else: ?>
            <tr>
                <td colspan='11' class='text-center'>No results</td>
            </tr>
            <?php endif; unset($_from); ?></div></td></a></td>
           
        <?php elseif ($this->_tpl_vars['filter'] == 0): ?>
        
        <thead class="dblur">
            <tr>
              <th scope="col" style="text-align: center;"></th>
              <th scope="col" style="text-align: center;">Registration Id</th>
              <th scope="col">Name</th>
              <th scope="col" style="text-align: center;">Class</th>
              <th scope="col" style="text-align: center;">Age</th>
              <th scope="col" style="text-align: center;">Dob</th>
              <th scope="col" style="text-align: center;">Gender</th>
              <th scope="col" style="text-align: center;">Action</th>
              <th scope="col" style="text-align: center;">Image</th>
              <th scope="col" style="text-align: center;">Gallery</th>
              <th scope="col" style="text-align: center;">Details</th>
              <th scope="col" style="text-align: center;">Status</th>
            </tr>
          </thead>
          <tbody>
            <?php $_from = $this->_tpl_vars['students']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['student']):
?>
            <tr draggable='true' data-id='<?php echo $this->_tpl_vars['student']['id']; ?>
'>
                <td class='text-center'>
                    <img draggable='false' class='<?php echo $this->_tpl_vars['student']['id']; ?>
' id='dragimage' src='./images/drag-and-drop.png' style='width:20px;height:auto;'>
                    <div id='<?php echo $this->_tpl_vars['student']['id']; ?>
' style='display:none; width:20px; height:20px;' class='spinner-border text-primary' role='status'></div>
                        <span class='sr-only'></span>
                    </div>
                </td>
                <td class='text-center'><?php echo $this->_tpl_vars['student']['register_id']; ?>
</td>
                <td><?php echo $this->_tpl_vars['student']['name']; ?>
</td>
                <td class='text-center'><?php echo $this->_tpl_vars['student']['class']; ?>
</td>
                <td class='text-center'><?php echo $this->_tpl_vars['student']['age']; ?>
</td>
                <td class='text-center'><?php echo $this->_tpl_vars['student']['dob']; ?>
</td>
                <td class='text-center'><?php echo $this->_tpl_vars['student']['gender']; ?>
</td>
                <td class='text-center'>
                    <a draggable='false' href='<?php echo $this->_tpl_vars['self']; ?>
?action=update&id=<?php echo $this->_tpl_vars['student']['id']; ?>
'>
                        <img draggable='false' src='./images/edit.png' style='width:20px;height:auto;'>
                    </a>
                    <div style='display:inline-block; width:10px;'></div>
                    <a draggable='false' href='#' onclick='confirmDelete("<?php echo $this->_tpl_vars['student']['id']; ?>
")'>
                        <img draggable='false' src='./images/delete.png' style='width:20px;height:auto;'>
                    </a>
                </td>
                <td class='text-center'>
                    <a draggable='false' href='#' onclick='passMessage("<?php echo $this->_tpl_vars['student']['photo']; ?>
")'>
                        <img draggable='false' src='./images/witness.png' style='width:20px;height:auto;'>
                    </a>
                </td>
                <td class='text-center'>
                    <a draggable='false' href='<?php echo $this->_tpl_vars['self']; ?>
?action=gallery&id=<?php echo $this->_tpl_vars['student']['id']; ?>
'>
                        <img draggable='false' src='./images/gallery.png' style='width:20px;height:auto;'>
                    </a>
                </td>
                <td draggable='false'>
                    <a draggable='false' style='text-decoration:none;' href='#modal-10' id='details' class='btn-sm btn-success' 
                        data-father-name='<?php echo $this->_tpl_vars['student']['father_name']; ?>
' data-father-number='<?php echo $this->_tpl_vars['student']['father_number']; ?>
' 
                        data-father-mail='<?php echo $this->_tpl_vars['student']['father_mail']; ?>
' data-mother-name='<?php echo $this->_tpl_vars['student']['mother_name']; ?>
' 
                        data-mother-number='<?php echo $this->_tpl_vars['student']['mother_number']; ?>
' data-mother-mail='<?php echo $this->_tpl_vars['student']['mother_mail']; ?>
' 
                        data-student-name='<?php echo $this->_tpl_vars['student']['name']; ?>
'>
                        <i class='text-success'>Parents Details</i>
                    </a>
                </td>
                <td class='text-center'>
                    <div class='form-check form-switch'>
                        <input class='form-check-input input-switch' type='checkbox' id='<?php echo $this->_tpl_vars['student']['id']; ?>
' <?php if ($this->_tpl_vars['student']['status'] == 'active'): ?>checked<?php endif; ?>>
                    </div>
                </td>
            </tr>
            <?php endforeach; else: ?>
            <tr>
                <td colspan='11' class='text-center'>No results</td>
            </tr>
            <?php endif; unset($_from); ?></div></td></a></td>

            

   </tbody>
    </table>
    </div>
    </div>
  </div>

  <div data-ml-modal="" id="modal-10" style="display: none;">
    <a href="#!" class="modal-overlay"></a>
    <div class="modal-dialog modal-dialog-lg bg-white">
        <a href="#!" class="modal-close">&times;</a>
        <h3>Parent Details</h3>
        <div class="modal-content newspaper">
            <ul>
                <li><strong>Student Name:</strong> <span id="student-name"></span></li>
                <li><strong>Father Name:</strong> <span id="father-name"></span></li>
                <li><strong>Father Number:</strong> <span id="father-number"></span></li>
                <li><strong>Father Email:</strong> <span id="father-mail"></span></li>
                <li><strong>Mother Name:</strong> <span id="mother-name"></span></li>
                <li><strong>Mother Number:</strong> <span id="mother-number"></span></li>
                <li><strong>Mother Email:</strong> <span id="mother-mail"></span></li>
            </ul>
        </div>
    </div>
</div>
</div>
</div>

<?php elseif ($this->_tpl_vars['filter'] == 2): ?>
<!-- update ===================================update ===============================  update =======================================================-->

<?php endif; ?>


<?php echo '
<script>
  const modal = document.querySelector("#details");
  if (modal) {
    modal.addEventListener("click", function() {
      document.getElementById(\'modal-10\').style.display = \'block\';
    });
  }



// Listen for the click event on the \'Parents Details\' link
document.querySelectorAll(\'.btn-success\').forEach(button => {
    button.addEventListener(\'click\', function() {
        // Get the parent\'s details from data attributes
        const fatherName = this.getAttribute(\'data-father-name\');
        const fatherNumber = this.getAttribute(\'data-father-number\');
        const fatherMail = this.getAttribute(\'data-father-mail\');
        const motherName = this.getAttribute(\'data-mother-name\');
        const motherNumber = this.getAttribute(\'data-mother-number\');
        const motherMail = this.getAttribute(\'data-mother-mail\');
        const studentName = this.getAttribute(\'data-student-name\');
        console.log(studentName);

        // Populate the modal with the parent\'s details
        document.getElementById(\'father-name\').textContent = fatherName;
        document.getElementById(\'father-number\').textContent = fatherNumber;
        document.getElementById(\'father-mail\').textContent = fatherMail;
        document.getElementById(\'mother-name\').textContent = motherName;
        document.getElementById(\'mother-number\').textContent = motherNumber;
        document.getElementById(\'mother-mail\').textContent = motherMail;
        document.getElementById(\'student-name\').textContent = studentName;

        // Open the modal
        document.getElementById(\'modal-10\').style.display = \'block\';
    });
});

// Close the modal when the close button is clicked
document.querySelector(\'.modal-close\').addEventListener(\'click\', function() {
    document.getElementById(\'modal-10\').style.display = \'none\';
});



  const table = document.querySelector("#studentTable tbody");
  let draggedRow = null;

  table.addEventListener("dragstart", (e) => {
    draggedRow = e.target;
    e.target.classList.add("dragging");
    e.target.style.opacity = "0.5"; // Add opacity when dragging starts
  });

  table.addEventListener("dragover", (e) => {
    e.preventDefault();
    const afterElement = getDragAfterElement(table, e.clientY);
    if (afterElement == null) {
      table.appendChild(draggedRow);
    } else {
      table.insertBefore(draggedRow, afterElement);
    }
  });

  table.addEventListener("dragend", () => {
    draggedRow.classList.remove("dragging");
    draggedRow.style.opacity = "1"; // Reset opacity when dragging ends
    
    showLoader(draggedRow.getAttribute("data-id"));
    updatePriorities();
  });

  function getDragAfterElement(container, y) {
    const draggableElements = [...container.querySelectorAll("tr:not(.dragging)")];
    return draggableElements.reduce((closest, child) => {
      const box = child.getBoundingClientRect();
      const offset = y - box.top - box.height / 2;
      if (offset < 0 && offset > closest.offset) {
        return { offset: offset, element: child };
      } else {
        return closest;
      }
    }, { offset: Number.NEGATIVE_INFINITY }).element;
  }

  function updatePriorities() {
    const rows = table.querySelectorAll("tr");
    const order = Array.from(rows).map((row, index) => ({
      id: row.getAttribute("data-id"),
      priority: index + 1
    }));
    console.log(order);
    fetch("update_priority.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(order)
    })
    .then(response => response.text())  // Get the response as text first
    .then(data => {
      console.log(data);  // Log the actual response
      try {
        const jsonData = JSON.parse(data);
        console.log(jsonData.message);
        hideLoader(draggedRow.getAttribute("data-id"));
      } catch (error) {
        // console.error("Error parsing JSON:");
        hideLoader(draggedRow.getAttribute("data-id"));
      }
    })
    .catch(error => {
      console.error("Error updating priorities:", error);
      hideLoader(draggedRow.getAttribute("data-id"));
    });
  }

  function showLoader(dataId) {
    document.getElementsByClassName(dataId)[0].style.display = \'none\';
    document.getElementById(dataId).style.display = \'block\';

  }

  function hideLoader(dataId) {
    document.getElementById(dataId).style.display = \'none\';
    document.getElementsByClassName(dataId)[0].style.display = \'block\';


  }
</script>
'; ?>

    <script src="js/modal.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>