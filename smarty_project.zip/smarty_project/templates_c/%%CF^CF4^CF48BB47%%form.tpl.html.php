<?php /* Smarty version 2.6.19, created on 2025-02-19 14:49:39
         compiled from form.tpl.html */ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css_files/form.css">
</head>
<body class="">
    <!-- nav -->
    <!-- <ul class="nav justify-content-center">
        <li class="nav-item">
            <a class="nav-link  btn btn-warning mt-2" aria-current="page" href="view.php">Home</a>
        </li>
        
        <li class="nav-item">
            <a class="nav-link btn btn-warning mt-2" href="form.php">Add Student</a>
        </li>
        
        <li class="nav-item ">
            <a class="nav-link btn btn-warning mt-2" href="class_insert.php">Add Class</a>
        </li>
    </ul> -->
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'nav.tpl.html', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<!-- loader -->
<div id="blockScreen" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background-color:rgba(0, 0, 0, 0.22); z-index:9999;">
    <div id="loader"   style=" position: absolute; left: 50%; top: 35%;" class="spinner-grow text-info" role="status">
        <span class="visually-hidden">Loading...</span>
    </div>           
  </div>
  <!-- loader end -->
<div class=" col-md-8 container-form  mt-4 dblur ">
<!-- <a href="view.php"><img src="https://img.icons8.com/?size=100&id=80689&format=png&color=000000" style = "margin-left:1%" alt="back" width="40px" height="40px"></a> -->

    <center><h3>Student Registration</h3></center>
    <form action="form.php" method="post" enctype="multipart/form-data" onsubmit="<?php echo 'if (!validate()) { document.getElementById(\'blockScreen\').style.display = \'none\'; document.querySelector(\'.dblur\').style.filter = \'none\'; return false; }'; ?>
">
    
    
    <div class="row">
        <div class="col-12 col-md-4">
            <div class="mb-3">
                <label for="student_id" class="form-label">Registration Id</label>
                <input type="text" name="student_id" class="form-control form-bottom" id="student_id" value = "<?php echo $this->_tpl_vars['registerid']; ?>
"  readonly>
            </div>    
            
        </div>
        <div class="col-12 col-md-4">
            <div class="mb-3">
                <label for="fname" class="form-label"><span class="text-danger">*</span>First Name</label>
                <input type="text" name="fname" class="form-control form-bottom" id="fname" >
                <span class="text-danger size" id = "alertfname"></span>
            </div>
        </div>
        <div class="col-12 col-md-4">
            <div class="mb-3">
                <label for="lname" class="form-label"><span class="text-danger">*</span>Last Name</label>
                <input type="text" name="lname" class="form-control form-bottom" id="lname" >
                <span class="text-danger size" id = "alertlname"></span>
            </div>
        </div>
        
    </div>
    <div class="row">
        <div class="col-12 col-md-4">
            <div class="mb-3">
                <label for="dob" class="form-label"><span class="text-danger">*</span>Dob</label>
                <input type="date" name="dob" class="form-control form-bottom" id="dob" onchange="dobCall(this.value)" >
                <span class="text-danger size" id = "alertdob"></span>
            </div>
        </div>
        <div class="col-12 col-md-4">
            <div class="mb-3">
                <label for="age" class="form-label"><span class="text-danger">*</span>Age</label>
                <input type="number" name="age" class="form-control form-bottom" id="age"  readonly>
                <span class="text-danger size" id = "alertage"></span>

            </div>
        </div>
        <div class="col-12 col-md-4">
            <div class="mb-3">
                <label for="class"><span class="text-danger">*</span>Class</label>
                <div class="dropdown">
                <select class="form-select input-select" name="class" id="class_id" aria-label="Default select example" >
                    <option value=""></option>       
                </select>
                <span class="text-danger size" id = "alertclass"></span>
                </div>
            </div>
        </div>
        
    </div>
    <div class="row">
    <div class="col-12 col-md-6">
        <div class="mb-3">
            <label for="file" class="form-label"><span class="text-danger">*</span>Image</label>
            <input type="file" name="file" class="form-control" id="file" style="margin:0px;" onchange="showViewButton()">
            <span class="text-danger size" id="alertimage"><i>upload files png,jpg,jpeg.(5MB)</i></span>
        </div>
        <div class="mb-3">
            <button type="button" id="viewButton" class="btn btn-info mt-2" style="display:none;" onclick="viewImage()">View</button>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="imageModal" tabindex="-1" aria-labelledby="imageModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="imageModalLabel">Image Preview</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <img id="imagePreview" src="#" alt="Image Preview" style="max-width:100%; height:auto;">
                </div>
            </div>
        </div>
    </div>

    
        <div class="col-12 col-md-6">
            <div class="mb-3">
            <label for="files" class="form-label " >Gallery:</label>
            <input type="file" class="form-control" name="files[]" id="files" multiple="multiple" onchange="showGalleryButton()">
            </div>
            <div class="text-center" style="margin-top:-20px">
            <span class="text-danger text-center size" id = ""><i>upload files png,jpg,jpeg.(5MB)</i></span>
            </div>
            <div class="mb-3">
                <button type="button" id="galleryButton" class="btn btn-info mt-2" style="display:none;" onclick="viewGallery()">View Gallery</button>
            </div>
        </div>

        <!-- Gallery Modal -->
        <div class="modal fade" id="galleryModal" tabindex="-1" aria-labelledby="galleryModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="galleryModalLabel">Gallery Preview</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div id="galleryPreview" class="d-flex flex-wrap"></div>
                    </div>
                </div>
            </div>
        </div>

       
    </div>
    <div class="row mt-2">
        <div class="col-12 col-md-8">
            <div class="mb-3">
                
                <div>
                <label for="gender" class="form-label"><span class="text-danger">*</span>Gender : </label>
                    <div class="form-check form-check-inline">
                        <input type="radio" name="gender" class="form-check-input" id="male" value="male" >
                        <label class="form-check-label" for="male">Male</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input type="radio" name="gender" class="form-check-input" id="female" value="female" >
                        <label class="form-check-label" for="female">Female</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input type="radio" name="gender" class="form-check-input" id="other" value="other" >
                        <label class="form-check-label" for="other">Other</label>
                    </div>
                    <span class="text-danger size" id = "alertgender"></span>

                </div>
            </div>
        </div>
    </div>
    
    <div class="row mt-2">
        <div class="col-12">
            <h3>Parent Details</h3>
        </div>
    </div>
    
    <div class="row border rounded">
        <div class="col-12 col-md-4">
                <div class="mb-3">
                    <label for="fathername" class="form-label"><span class="text-danger">*</span>Father Name</label>
                    <input type="text" name="fathername" class="form-control form-bottom" id="fathername"  >
                    <span class="text-danger size"></span>
                </div>
        </div>
        <div class="col-12 col-md-4">
                <div class="mb-3">
                    <label for="fphonenumber" class="form-label"><span class="text-danger">*</span>Mobile Number</label>
                    <input type="text" name="fphonenumber" class="form-control form-bottom" id="fphonenumber"  >
                    <span class="text-danger size"></span>
                </div>
        </div>
        <div class="col-12 col-md-4">
                <div class="mb-3">
                    <label for="femailid" class="form-label"><span class="text-danger">*</span>Email Id</label>
                    <input type="text" name="femailid" class="form-control form-bottom" id="femailid"  >
                    <span class="text-danger size"></span>
                </div>
        </div>
    </div>
    <div class="row border rounded mt-2">
        <div class="col-12 col-md-4">
                <div class="mb-3">
                    <label for="mothername" class="form-label"><span class="text-danger">*</span>Mother Name</label>
                    <input type="text" name="mothername" class="form-control form-bottom" id="mothername"  >
                    <span class="text-danger size"></span>
                </div>
        </div>
        <div class="col-12 col-md-4">
                <div class="mb-3">
                    <label for="mphonenumber" class="form-label"><span class="text-danger">*</span>Mobile Number</label>
                    <input type="text" name="mphonenumber" class="form-control form-bottom" id="mphonenumber"  >
                    <span class="text-danger size"></span>
                </div>
        </div>
        <div class="col-12 col-md-4">
                <div class="mb-3">
                    <label for="memailid" class="form-label"><span class="text-danger">*</span>Email Id</label>
                    <input type="text" name="memailid" class="form-control form-bottom" id="memailid"  >
                    <span class="text-danger size"></span>
                </div>
        </div>
    </div>

    <div class="row">
    <div class="col-12 col-md-8">
            <div class="mb-3">
                
                <div>
                <label for="primary" class="form-label"><span class="text-danger">*</span>Primary Contact: </label>
                    <div class="form-check form-check-inline">
                        <input type="radio" name="primary" class="form-check-input" id="father" value="father" >
                        <label class="form-check-label" for="father">Father</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input type="radio" name="primary" class="form-check-input" id="mother" value="mother" >
                        <label class="form-check-label" for="mother">Mother</label>
                    </div>
                    <span class="text-danger  size" id = "alertprimary"></span>

                </div>
            </div>
    </div>
    
    <div class="row mt-2">
        <div class="col-12 col-md-6">
            <div id="hobbies-container">
                <div class="dem mb-3">
                    <label for="">Hobbies</label>
                    <div class="dem row">
                        <div class="col-12">
                            <div class="d-flex flex-wrap">
                                <?php $_from = $this->_tpl_vars['hobbies']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['hobby']):
?>
                                    <div class="form-check me-3">
                                        <input class="form-check-input" type="checkbox" name="hobbies[]" value="<?php echo $this->_tpl_vars['hobby']['hobbies_id']; ?>
" id="hobby-<?php echo $this->_tpl_vars['hobby']['hobbies_id']; ?>
">
                                        <label class="form-check-label" for="hobby-<?php echo $this->_tpl_vars['hobby']['hobbies_id']; ?>
">
                                            <?php echo $this->_tpl_vars['hobby']['hobbies']; ?>

                                        </label>
                                    </div>
                                <?php endforeach; endif; unset($_from); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
   

    


   
    


    <div class="row">
        <div class="col-12 d-flex justify-content-between mt-3">
            <!-- Left-aligned buttons -->
            <div class="d-flex col-4">
                <!-- <a class="btn btn-primary btn-sm" href="view.php" style="width: 70px;margin-right: 10px;">Home</a> -->
                <a class="btn btn-warning btn-sm " href="view.php">Cancel</a>
            </div>
            <!-- Right-aligned buttons -->
            <div class="d-flex col-4 justify-content-end">
                
                <input type="submit" name="submit" class="btn btn-primary btn-sm ml-2 " style="width:70px;" value="Register">
            </div>
        </div>
    </div>


    </form>
    </div>


<script src="js/form.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>