<?php /* Smarty version 2.6.19, created on 2025-02-18 17:25:25
         compiled from nav.tpl.html */ ?>
    <!-- nav  end-->

    <nav class="navbar sticky-top " style="background-color:#fff;">
        <div class="container-fluid">
          <a class="" href="#offcanvasExample" role="button" aria-controls="offcanvasExample" style="width: 14%;height: 4%;" onmouseover="openOffcanvas();" onmouseout="this.style.opacity='1';">
            <img src="images/menu.svg" alt="menu" style="width: 28%;">
          </a>
        </div>
      </nav>
      <!-- offcanvas -->
      <div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
        <div class="offcanvas-header">
          <h5 class="offcanvas-title" id="offcanvasExampleLabel">Menu</h5>
          <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
          <div class="list-group ">
            <!-- Home Link -->
            <a href="student_view.php" class="list-group-item list-group-item-action" style="background-color: #cfe2ff;" onmouseover="this.style.backgroundColor='#b0d4ff';" onmouseout="this.style.backgroundColor='#cfe2ff';">
              Home
            </a>
  
            <!-- Classes Link -->
            <a href="class_insert.php" class="list-group-item list-group-item-action mt-2" style="background-color: #cfe2ff;" onmouseover="this.style.backgroundColor='#b0d4ff';" onmouseout="this.style.backgroundColor='#cfe2ff';">
              Classes
            </a>
  
            <!-- View Students Link -->
            <a href="view.php" class="list-group-item list-group-item-action mt-2" style="background-color: #cfe2ff;" onmouseover="this.style.backgroundColor='#b0d4ff';" onmouseout="this.style.backgroundColor='#cfe2ff';">
              View Students
            </a>
            <a href="form.php" class="list-group-item list-group-item-action mt-2" style="background-color: #cfe2ff;" onmouseover="this.style.backgroundColor='#b0d4ff';" onmouseout="this.style.backgroundColor='#cfe2ff';">
              Student Registration
            </a>
            <a href="view.php?action=hobbies" class="list-group-item list-group-item-action mt-2" style="background-color: #cfe2ff;" onmouseover="this.style.backgroundColor='#b0d4ff';" onmouseout="this.style.backgroundColor='#cfe2ff';">
              Add Hobbies
            </a>
          </div>
        </div>
      </div>
      <!-- offcanvas end -->
  
      <?php echo '
      <script>
        function openOffcanvas() {
          var offcanvasElement = document.getElementById(\'offcanvasExample\');
          var bsOffcanvas = new bootstrap.Offcanvas(offcanvasElement);
          bsOffcanvas.show();
        }
      </script>
      '; ?>