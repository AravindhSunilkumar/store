<?php
require_once 'init.php';
$class = new class_details();
if($_SERVER['REQUEST_METHOD'] == 'GET' and (isset($_GET['dob']))){
    $dob = $_GET['dob'];
    $result = $class->getAgeAndClasses($dob);

    header('Content-Type: application/json');
    echo json_encode(array("status" => $result['age'], "classes" => $result['classes']));
    exit;
}
?>
?>