<?php
class parent_details{
    private $father_name;
    private $father_number;
    private $father_mail;
    private $mother_name;
    private $mother_number;
    private $mother_mail;
    public $db;

    public function __construct(){
        $this->db = new Database();
    }
    public function getDb() {
        return $this->db->getConnection();
    }
    public function getParentDetails(){
        $sql = "select * from parent_details";
        $result = $this->db->execute($sql);
        $parents = array();
        while($row = $result->fetch_assoc()){
            $parents[] = $row;
        }
        return $parents;
    }
    public function getParentDetailsByStudentId($student_id){
        $sql = "select * from parent_details where student_id = $student_id";
        $result = $this->db->execute($sql);
        $parents = array();
        while($row = $result->fetch_assoc()){
            $parents[] = $row;
        }
        return $parents;
    }
    public function insertParentDetails($student_id, $father_name, $father_number, $father_mail, $mother_name, $mother_number, $mother_mail, $primary_contact) {
        $sql = "INSERT INTO parent_details (student_id, father_name, father_number, father_mail, mother_name, mother_number, mother_mail, primary_contact)
                VALUES ('$student_id', '$father_name', '$father_number', '$father_mail', '$mother_name', '$mother_number', '$mother_mail', '$primary_contact')";
        return $this->db->execute($sql);
    }
}

?>