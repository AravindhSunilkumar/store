<?php
//hobbies
class student_hobbies{
    private $hobbies;
    public $db;

    public function __construct(){
        $this->db = new Database();
    }
    public function getDb() {
        return $this->db->getConnection();
    }
    public function getHobbies(){
        $sql = "select * from student_hobbies";
        $result = $this->db->execute($sql);
        $hobbies = array();
        while($row = $result->fetch_assoc()){
            $hobbies[] = $row;
        }
        return $hobbies;
    }
}

?>