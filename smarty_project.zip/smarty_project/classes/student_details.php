<?php



//Database 


//Student Class
class Student{
    private $name;
    private $registerid;
    private $class_id;
    private $age;
    private $dob;
    private $gender;
    private $photo;
    private $hobbies;
    private $priority;
    private $status;
    public $db;

    public function __construct(){
        $this->db = new Database();
    }
    // public function getDb() {
    //     return $this->db;
    // }
    public function getDb() {
        return $this->db->getConnection();  // Access the db connection via getter
    }
    public function registerId(){
        $sql = "SELECT * FROM student_details ORDER BY id DESC LIMIT 1";
        $result = $this->db->fetch($sql);
        return $this->registerid = str_pad($result['register_id']+1,4,'0',STR_PAD_LEFT);
    }

    public function getHobbies(){
        $sql = "select * from student_hobbies";
        $result = $this->db->execute($sql);
        $hobbies = array();
        while($row = $result->fetch_assoc()){
            $hobbies[] = $row;
        }
        return $hobbies;
    }

    public function getPriority() {
        $sql = "SELECT * FROM student_details ORDER BY priority DESC LIMIT 1";
        $result = $this->db->execute($sql);
        $data = $result->fetch_assoc();
        return $data ? $data['priority'] + 1 : 1;
    }

    public function uploadImage($file, $student_id) {
        $target_dir = "student_images/";
        $target_file = $target_dir . $student_id . '_' . basename($file["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        $check = getimagesize($file["tmp_name"]);
        
        if ($check === false) {
            return false;
        }
        
        if (file_exists($target_file)) {
            return false;
        }

        if ($file["size"] > 5000000) { // 5MB
            return false;
        }

        if (!in_array($imageFileType, array('jpg', 'jpeg', 'png', 'gif'))) {
            return false;
        }

        if (move_uploaded_file($file["tmp_name"], $target_file)) {
            return $target_file;
        }

        return false;
    }

    public function insertStudent($name, $class, $age, $gender, $priority, $photo, $register_id, $dob, $hobbies) {
        $sql = "INSERT INTO student_details(name, class_id, age, gender, priority, photo, register_id, dob, hobbies)
                VALUES ('$name', '$class', '$age', '$gender', '$priority', '$photo', '$register_id', '$dob', '$hobbies')";
        
        if ($this->db->execute($sql)) {
            return $this->getDb()->insert_id;
        }
        
        return false;
    }

    public function insertGallery($student_id, $gallery_photo) {
        $sql_gallery = "INSERT INTO student_gallery(student_id, gallery_photo) VALUES ('$student_id', '$gallery_photo')";
        return $this->db->execute($sql_gallery);
    }

    public function insertParentDetails($student_id, $father_name, $father_number, $father_mail, $mother_name, $mother_number, $mother_mail, $primary_contact) {
        $sql = "INSERT INTO parent_details (student_id, father_name, father_number, father_mail, mother_name, mother_number, mother_mail, primary_contact)
                VALUES ('$student_id', '$father_name', '$father_number', '$father_mail', '$mother_name', '$mother_number', '$mother_mail', '$primary_contact')";
        return $this->db->execute($sql);
    }

    public function getStudents(){
        $sql = $sql = "SELECT 
        student_details.id, 
        student_details.name, 
        student_details.age, 
        student_details.gender, 
        student_details.photo, 
        student_details.register_id, 
        student_details.status, 
        student_details.dob, 
        class_details.class, 
        parent_details.father_name, 
        parent_details.father_number,
        parent_details.father_mail,
        parent_details.mother_name,
        parent_details.mother_number,
        parent_details.mother_mail
    FROM 
        student_details 
    INNER JOIN 
        class_details ON student_details.class_id = class_details.id 
    LEFT JOIN 
        parent_details ON parent_details.student_id = student_details.id
    WHERE 
        (student_details.status = 'active' OR student_details.status = 'inactive')
    ORDER BY 
        student_details.priority ASC;
    ";
        $result = $this->db->execute($sql);
        $students = array();
        while($row = $result->fetch_assoc()){
            $students[] = $row;
        }
        return $students;
    }
    public function getfilterStudent($studentname,$c_id){
        $sql = "SELECT 
        student_details.id,
        student_details.name,
        student_details.age,
        student_details.gender,
        class_details.class,
        student_details.priority,
        student_details.photo,
        student_details.register_id,
        student_details.status,
        student_details.dob,
         parent_details.father_name, 
        parent_details.father_number,
        parent_details.father_mail,
        parent_details.mother_name,
        parent_details.mother_number,
        parent_details.mother_mail 
      FROM student_details 
    INNER JOIN class_details ON student_details.class_id = class_details.id 
    LEFT JOIN parent_details ON parent_details.student_id = student_details.id
    WHERE (student_details.status = 'active' OR student_details.status = 'inactive')";


    $conditions = array();

    if ($c_id !== '') {
    $conditions[] = "student_details.class_id = '$c_id'";
    }

    if (!empty($studentname)) {
    if(is_numeric($studentname)){
    $conditions[] = "student_details.register_id = '$studentname'";
    }else{
    $conditions[] = "student_details.name LIKE '%$studentname%'";
    }
    }

    // if (!empty($registerid)) {
    //     $conditions[] = "student_details.register_id = '$registerid'";
    // }


    if (count($conditions) > 0) {
    $sql .= " AND " . implode(" AND ", $conditions);
    }


    $sql .= " ORDER BY student_details.priority ASC";
    $result = $this->db->execute($sql);
    $students = array();
    while($row = $result->fetch_assoc()){
        $students[] = $row;

        
    }
    return $students;
    }
    public function updatePriority($id, $priority) {
        $sql = "UPDATE student_details SET priority = '$priority' WHERE id = '$id'";
        if ($this->db->execute($sql) === TRUE) {
            return json_encode(array("message" => "Priority for ID '$id' updated successfully"));
          
        } else {
            return json_encode(array("error" => "Database error for ID '$id': " . $conn->error));
           
        }
    }
    public function updateStatus($id,$status){
        $sql = "UPDATE student_details SET status = '$status' WHERE id = '$id'";
        if ($this->db->execute($sql) === TRUE) {
            return json_encode(array("message" => "Status for ID '$id' updated successfully"));
          
        } else {
            return json_encode(array("error" => "Database error for ID '$id': " . $conn->error));
           
        }
    }
    public function getStudentById($id){
        $sql="SELECT 
        student_details.id,
        student_details.name,
        student_details.age,
        student_details.gender,
        class_details.class,
        student_details.priority,
        student_details.photo,
        student_details.register_id,
        student_details.status,
        student_details.dob,
         parent_details.father_name, 
        parent_details.father_number,
        parent_details.father_mail,
        parent_details.mother_name,
        parent_details.mother_number,
        parent_details.mother_mail 
      FROM student_details 
    INNER JOIN class_details ON student_details.class_id = class_details.id 
    LEFT JOIN parent_details ON parent_details.student_id = student_details.id
    WHERE student_details.id = '$id'";
        $result = $this->db->execute($sql);
        $details = array();
        while($row = $result->fetch_assoc()){
            $details[] = $row;
    
            
        }
        return $details;
    }


}


?>
