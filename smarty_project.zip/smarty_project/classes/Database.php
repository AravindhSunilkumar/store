<?php
class Database {
    private $host = 'localhost';
    private $user = 'root';
    private $password = 'mysqlpass';
    private $database = 'student';
    public $conn;

    public function __construct(){
        $this->conn = new mysqli($this->host,$this->user,$this->password,$this->database);
        if($this->conn->connect_error){
            die('Connection failed: '.$this->conn->connect_error);
        }
        return $this->conn;
    }

    public function getConnection() {
        return $this->conn;
    }
    public function execute($query){
        return $this->conn->query($query);
    }

    public function fetch($query){
        return $this->conn->query($query)->fetch_assoc();
    }

}

?>