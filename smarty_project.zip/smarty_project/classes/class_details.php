<?php
class class_details{
    private $class_name;
    private $age_from;
    private $age_to;
    private $class_id;
    public $db;

    public function __construct(){
        $this->db = new Database();
    }
    public function getDb() {
        return $this->db->getConnection();
    }
    
     // calculate age 
     public function getAgeAndClasses($dob){
        $dobDate = new DateTime($dob);
        $currentDate = new DateTime();
        $age = $currentDate->diff($dobDate)->y;

        $sql = "SELECT * FROM class_details WHERE age_from <= $age AND age_to >= $age";
        $result = $this->db->execute($sql);
        $classes = array();
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $classes[] = $row;
            }
        }

        return array("age" => $age, "classes" => $classes);
    }
    public function getClasses(){
        $sql = "SELECT * FROM class_details WHERE status = 'active' ORDER BY class_priority ASC";
        $result = $this->db->execute($sql);
        $classes = array();
        while($row = $result->fetch_assoc()){
            $classes[] = $row;
        }
        return $classes;
    }
}
?>