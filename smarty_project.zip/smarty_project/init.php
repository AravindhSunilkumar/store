<?php
require_once('smarty/libs/Smarty.class.php');
require_once('classes/Database.php');
require_once('classes/class_details.php');
require_once('classes/parent_details.php');
require_once('classes/student_details.php');
require_once('classes/student_hobbies.php');
// require_once('classes.php');

$smarty = new Smarty();
$smarty->compile_check = true;



?>