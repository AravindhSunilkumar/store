/*
SQLyog Ultimate v10.00 Beta1
MySQL - 5.1.73-community : Database - student
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`student` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `student`;

/*Table structure for table `class_details` */

DROP TABLE IF EXISTS `class_details`;

CREATE TABLE `class_details` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `class` varchar(50) NOT NULL,
  `age_from` smallint(6) NOT NULL,
  `age_to` smallint(6) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `class_priority` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

/*Data for the table `class_details` */

insert  into `class_details`(`id`,`class`,`age_from`,`age_to`,`status`,`class_priority`) values (1,'1st standard',5,7,'active',2),(2,'2th standard',7,9,'active',3),(4,'4th standard',11,13,'active',5),(5,'5th standard',13,15,'active',6),(6,'6th standard',15,16,'active',7),(11,'7th standard',16,18,'active',1),(13,'3rd standard',9,11,'active',4);

/*Table structure for table `parent_details` */

DROP TABLE IF EXISTS `parent_details`;

CREATE TABLE `parent_details` (
  `parent_id` bigint(10) NOT NULL AUTO_INCREMENT,
  `student_id` bigint(10) NOT NULL,
  `father_name` varchar(100) NOT NULL,
  `father_number` varchar(10) NOT NULL,
  `father_mail` varchar(50) NOT NULL,
  `mother_name` varchar(100) NOT NULL,
  `mother_number` varchar(10) NOT NULL,
  `mother_mail` varchar(50) NOT NULL,
  `primary_contact` enum('father','mother') NOT NULL,
  PRIMARY KEY (`parent_id`),
  KEY `parent_details` (`student_id`),
  CONSTRAINT `parent_details` FOREIGN KEY (`student_id`) REFERENCES `student_details` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

/*Data for the table `parent_details` */

insert  into `parent_details`(`parent_id`,`student_id`,`father_name`,`father_number`,`father_mail`,`mother_name`,`mother_number`,`mother_mail`,`primary_contact`) values (9,62,'sunilkumar','1234567890','lavax68876@shouxs.com','sandth','1234567890','lavax68876@shouxs.com','father'),(10,63,'aravindh','1234567890','lavax68876@shouxs.com','ads','1234567890','lavax68876@shouxs.com','father'),(11,64,'aravindh','1234567890','lavax68876@shouxs.com','ads','1234567890','lavax68876@shouxs.com','father'),(13,65,'Raj','1234567890','lavax68876@shouxs.com','ads','1234567890','lavax68876@shouxs.com','father'),(14,66,'aravindh','1234567890','lavax68876@shouxs.com','ads','1234567890','lavax68876@shouxs.com','father'),(15,67,'Raj','1234567890','lavax68876@shouxs.com','sandth','1234567890','lavax68876@shouxs.com','father'),(16,68,'aravindh','1234567890','lavax68876@shouxs.com','ads two','1234567890','lavax68876@shouxs.com','father'),(19,69,'aravindh','1234567890','lavax68876@shouxs.com','ads','1234567890','lavax68876@shouxs.com','father'),(20,70,'aravindh','1234567890','lavax68876@shouxs.com','ads','1234567890','lavax68876@shouxs.com','father'),(21,71,'Raj','1234567890','lavax68876@shouxs.com','ads','1234567890','lavax68876@shouxs.com','father'),(22,72,'Raj','1234567890','lavax68876@shouxs.com','sandth','1234567890','lavax68876@shouxs.com','father'),(23,73,'aravindh','1234567890','lavax68876@shouxs.com','sandth','1234567890','lavax68876@shouxs.com','father'),(24,75,'aravindh','1234567890','lavax68876@shouxs.com','sandth','1234567890','lavax68876@shouxs.com','father'),(25,76,'Raj','1234567890','kitihop790@lxheir.com','ads','1234567890','lavax68876@shouxs.com','father'),(26,77,'Raj','1234567890','lavax68876@shouxs.com','ads','1234567890','lavax68876@shouxs.com','mother'),(27,78,'aravindh','1234567890','kitihop790@lxheir.com','ads','1234567890','lavax68876@shouxs.com','father');

/*Table structure for table `student_details` */

DROP TABLE IF EXISTS `student_details`;

CREATE TABLE `student_details` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `register_id` varchar(10) NOT NULL,
  `class_id` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `age` smallint(6) NOT NULL,
  `dob` date NOT NULL,
  `gender` enum('male','female','other') NOT NULL,
  `photo` text NOT NULL,
  `hobbies` tinytext,
  `priority` smallint(6) DEFAULT NULL,
  `status` enum('active','inactive','deleted') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `class_id` (`class_id`),
  CONSTRAINT `student_details_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `class_details` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=latin1;

/*Data for the table `student_details` */

insert  into `student_details`(`id`,`register_id`,`class_id`,`name`,`age`,`dob`,`gender`,`photo`,`hobbies`,`priority`,`status`) values (62,'0001',1,'aravindh sunilkumar',5,'2020-01-11','male','students_images/_Screenshot 2025-02-05 124227.png','',1,'active'),(63,'0002',5,'sunny soman',5,'2020-01-01','female','students_images/0002_Screenshot 2025-02-05 124227.png','',4,'active'),(64,'0003',2,'hari k k',9,'2016-01-11','male','students_images/0003_Screenshot 2025-02-05 124227.png',NULL,3,'deleted'),(65,'0004',2,'ramu kk',7,'2018-01-01','male','students_images/0004_Screenshot 2025-02-05 124227.png',NULL,5,'active'),(66,'0005',4,'abc sonu',10,'2015-01-12','male','students_images/0005_Screenshot 2025-02-05 124227.png',NULL,11,'active'),(67,'0006',5,'abcd ef',12,'2013-01-12','male','students_images/0006_Screenshot 2025-02-05 124227.png','',9,'active'),(68,'0007',6,'abc k',13,'2012-01-12','male','students_images/0007_Screenshot 2025-02-05 124227.png','1,2,3,4',3,'active'),(69,'0008',4,'vivek de',10,'2015-01-13','male','students_images/0008_Screenshot 2025-02-05 124227.png','1,2',6,'active'),(70,'0009',5,'vivek sonu',12,'2013-01-13','male','students_images/0009_Screenshot 2025-02-05 124227.png','1,3',7,'active'),(71,'0010',4,'vivek de',11,'2014-01-13','male','students_images/0010_Screenshot 2025-02-05 124227.png','1,4',8,'active'),(72,'0011',2,'sonu sonu',9,'2016-01-13','male','students_images/0011_Screenshot 2025-02-05 124227.png','',10,'active'),(73,'0012',13,'adsd sonu',9,'2016-01-17','male','students_images/0012_Screenshot 2025-02-10 175019.png','8,',2,'active'),(74,'0013',13,'adsd sonu',9,'2016-01-01','male','student_images/0013_Screenshot 2025-02-05 124227.png','2',12,'active'),(75,'0014',13,'adsd sonu',9,'2016-01-01','male','student_images/0014_Screenshot 2025-02-05 124227.png','2',13,'active'),(76,'0015',2,'abc k',8,'2017-02-01','male','student_images/0015_Screenshot 2025-02-05 124227.png','2',14,'active'),(77,'0016',6,'adsd sonu',15,'2010-02-19','female','student_images/0016_Screenshot 2025-02-05 124227.png','4',15,'active'),(78,'0017',2,'adsd sonu k',9,'2016-02-04','male','student_images/0017_Screenshot 2025-02-05 124227.png','2',16,'active');

/*Table structure for table `student_gallery` */

DROP TABLE IF EXISTS `student_gallery`;

CREATE TABLE `student_gallery` (
  `gallery_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `student_id` bigint(20) NOT NULL,
  `gallery_photo` text,
  PRIMARY KEY (`gallery_id`),
  KEY `student_id` (`student_id`),
  CONSTRAINT `student_id` FOREIGN KEY (`student_id`) REFERENCES `student_details` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=latin1;

/*Data for the table `student_gallery` */

insert  into `student_gallery`(`gallery_id`,`student_id`,`gallery_photo`) values (58,62,'students_images/_Screenshot 2025-02-07 110312.png'),(61,66,'students_images/0005_Screenshot 2025-02-07 110312.png'),(62,67,'students_images/8026_Screenshot 2025-02-05 124227.png'),(63,67,'students_images/7648_Screenshot 2025-02-07 110312.png'),(64,65,'students_images/8863_Screenshot 2025-02-05 124227.png'),(65,68,'students_images/8912_Screenshot 2025-02-05 124227.png'),(66,70,'students_images/9489_Screenshot 2025-02-05 124227.png'),(67,72,'students_images/1600_Screenshot 2025-02-05 124227.png'),(68,73,'students_images/5413_Screenshot 2025-02-05 124227.png'),(69,75,'student_images/5406_Screenshot 2025-02-05 124227.png'),(70,76,'student_images/2815_Screenshot 2025-02-05 124227.png');

/*Table structure for table `student_hobbies` */

DROP TABLE IF EXISTS `student_hobbies`;

CREATE TABLE `student_hobbies` (
  `hobbies_id` bigint(11) NOT NULL AUTO_INCREMENT,
  `hobbies` varchar(20) NOT NULL,
  PRIMARY KEY (`hobbies_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

/*Data for the table `student_hobbies` */

insert  into `student_hobbies`(`hobbies_id`,`hobbies`) values (1,'Readings'),(2,'cooking'),(3,'Music'),(4,'traveling'),(8,'carroms'),(9,'Dancing');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
